Bones. Som el grup de l'Alberto Alegre i el Salvio Calvillo.
Abans d'executar el programa, es important que sapigues que hem implementat diversos modes d'execució, secuencial, en paralel i en multithreading.
En cas de tenir el paral·lel disponible recomenem activar aquest mode, es el mes eficient i es natiu de C++17, en cas de no tenir-ho disponible al teu pc, el programa no et deixarà activar-ho.
En cas de posar-ho en secuencial, recomenem no posar el máxim de partícules, ja que pot anar lent.
No recomenem fer servir el multithreading.