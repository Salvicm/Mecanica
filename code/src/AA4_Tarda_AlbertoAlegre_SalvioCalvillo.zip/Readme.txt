No hemos conseguido que los rebotes funcionen correctamente con la formula proporcionada en clase, entendemos que es lo correcto pero no sabemos donde nos está fallando. Sin embargo, el semi implicit euler, la detección de colisiones, y la corrección de la posición en caso de colisión nos está funcionando correctamente.

Hemos añadido unas lineas de puntos que indican la fuerza donde se aplica, su direccion y su magnitud.

El editor de parametros tiene un campo llamado Seed, este campo, cuando se termina el tiempo de reseteo genera otra seed y reinicia el cubo. Se puede poner un numero manualmente y probar el mismo spawn tantas veces como se quiera.